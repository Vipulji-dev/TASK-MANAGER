# Task Management System Backend

This is the backend for the Task Management System, built using Node.js and Express. It provides RESTful APIs for user authentication, task management, and user management.

## Features

- User Authentication
  - User registration
  - User login
- Task Management
  - Create, read, update, and delete tasks
- User Management
  - Get user details
  - Update user information

## Technologies Used

- Node.js
- Express
- TypeScript
- MongoDB or PostgreSQL (depending on your choice)
- JWT for authentication

## Getting Started

### Prerequisites

- Node.js installed on your machine
- MongoDB or PostgreSQL database set up

### Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd task-management-system/backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Set up your database connection in `src/utils/db.ts`.

4. Start the server:
   ```
   npm run start
   ```

### API Endpoints

- **Authentication**
  - `POST /api/auth/register` - Register a new user
  - `POST /api/auth/login` - Log in a user

- **Tasks**
  - `POST /api/tasks` - Create a new task
  - `GET /api/tasks` - Get all tasks
  - `PUT /api/tasks/:id` - Update a task
  - `DELETE /api/tasks/:id` - Delete a task

- **Users**
  - `GET /api/users/:id` - Get user details
  - `PUT /api/users/:id` - Update user information

## Running Tests

To run tests, use the following command:
```
npm test
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

## License

This project is licensed under the MIT License.