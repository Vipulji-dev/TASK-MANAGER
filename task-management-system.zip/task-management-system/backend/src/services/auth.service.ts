import { Injectable } from '@nestjs/common';
import { UserService } from './user.service';
import { JwtService } from '@nestjs/jwt';
import { User } from '../models/user.model';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
    constructor(
        private userService: UserService,
        private jwtService: JwtService,
    ) {}

    async registerUser(username: string, password: string, email: string): Promise<User> {
        const hashedPassword = await bcrypt.hash(password, 10);
        return this.userService.createUser({ username, password: hashedPassword, email });
    }

    async loginUser(username: string, password: string): Promise<{ accessToken: string }> {
        const user = await this.userService.findUserByUsername(username);
        if (user && await bcrypt.compare(password, user.password)) {
            const payload = { username: user.username, sub: user.id };
            return { accessToken: this.jwtService.sign(payload) };
        }
        throw new Error('Invalid credentials');
    }

    async validateUser(username: string): Promise<User | null> {
        return this.userService.findUserByUsername(username);
    }
}