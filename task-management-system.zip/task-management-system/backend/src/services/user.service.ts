import { Injectable } from '@nestjs/common';
import { User } from '../models/user.model';

@Injectable()
export class UserService {
    async getUser(userId: string): Promise<User> {
        return await User.findById(userId);
    }

    async updateUser(userId: string, userData: Partial<User>): Promise<User> {
        return await User.findByIdAndUpdate(userId, userData, { new: true });
    }

    async createUser(userData: User): Promise<User> {
        const user = new User(userData);
        return await user.save();
    }

    async deleteUser(userId: string): Promise<User> {
        return await User.findByIdAndDelete(userId);
    }
}