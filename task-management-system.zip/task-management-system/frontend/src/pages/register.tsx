import { useState } from 'react';
import RegisterForm from '../components/RegisterForm';

const RegisterPage = () => {
    const [error, setError] = useState(null);

    const handleRegister = async (userData) => {
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            });

            if (!response.ok) {
                throw new Error('Registration failed');
            }

            // Handle successful registration (e.g., redirect to login)
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div>
            <h1>Register</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <RegisterForm onRegister={handleRegister} />
        </div>
    );
};

export default RegisterPage;