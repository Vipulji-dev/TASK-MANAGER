import React, { useEffect, useState } from 'react';
import { TaskList } from '../components/TaskList';
import { fetchTasks } from '../utils/api';

const Dashboard = () => {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const getTasks = async () => {
            try {
                const data = await fetchTasks();
                setTasks(data);
            } catch (error) {
                console.error('Error fetching tasks:', error);
            } finally {
                setLoading(false);
            }
        };

        getTasks();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1>Your Tasks</h1>
            <TaskList tasks={tasks} />
        </div>
    );
};

export default Dashboard;