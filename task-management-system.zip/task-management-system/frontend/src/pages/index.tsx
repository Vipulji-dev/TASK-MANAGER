import React from 'react';
import Link from 'next/link';

const Home: React.FC = () => {
    return (
        <div>
            <h1>Welcome to the Task Management System</h1>
            <p>
                Manage your tasks efficiently and effectively. 
                Please <Link href="/login">login</Link> or <Link href="/register">register</Link> to get started.
            </p>
        </div>
    );
};

export default Home;